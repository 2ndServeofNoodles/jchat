<!-- JChat public-facing chatbot container -->
<div class="jchat-container">
    <div class="jchat-header">Chatbot</div>
    <div class="jchat-messages"></div>
    <div class="jchat-input-container">
        <input type="text" class="jchat-input" placeholder="Type your message...">
        <button class="jchat-send-btn">Send</button>
    </div>
</div>
