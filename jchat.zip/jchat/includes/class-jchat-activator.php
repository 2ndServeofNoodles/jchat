<?php

/**
 * Fired during plugin activation
 *
 * @link       https://jezweb.com.au
 * @since      1.0.0
 *
 * @package    Jchat
 * @subpackage Jchat/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Jchat
 * @subpackage Jchat/includes
 * @author     Jezweb <narelle@jezweb.net>
 */
class Jchat_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
<?php

// ... (previous code) ...

class Jchat_Activator {

	public static function activate() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$table_name = $wpdb->prefix . 'jchat_messages';

		$sql = "CREATE TABLE $table_name (
			id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			user_message text NOT NULL,
			gpt_response text NOT NULL,
			time datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id)
		) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
	}

}

