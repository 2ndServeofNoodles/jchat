<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://jezweb.com.au
 * @since      1.0.0
 *
 * @package    Jchat
 * @subpackage Jchat/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Jchat
 * @subpackage Jchat/includes
 * @author     Jezweb <narelle@jezweb.net>
 */
class Jchat_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
